@AbapCatalog.sqlViewName: 'ZSK_SQLE1_DCUST'
@EndUserText.label: 'Dimension customer master view'
// VDM : Virtual Data Model
// BASIC : only for the internal use and it will access tables directly
@VDM.viewType: #BASIC

// DIMENSION: it will tellS that CDS view of MASTER DATA 
@Analytics.dataCategory: #DIMENSION

// REPRESENTATIVE: This CDS View will be joined with other CDS Views based on  MATERIAL Column 
@ObjectModel.representativeKey: 'Cust_no'


define view ZSK_CDSE1_DIM_cust as select from kna1
{
    key kunnr as Cust_no,
        name1 as Cust_Name,
        ort01 as Cust_region    
}
