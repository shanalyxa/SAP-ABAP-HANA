@AbapCatalog.sqlViewName: 'ZSK_SQLE5_CUBE'

@EndUserText.label: 'cds cube sales model'
//  VDM : Virtual Data Model
// BASIC : only for the internal use and it will access tables directly
@VDM.viewType: #CONSUMPTION

// DIMENSION: it will tellS that CDS view of MASTER DATA 
@Analytics: 
        {
        dataCategory: #CUBE,
        // data extraction : it will allow BW or UI% to access this CDS view
        dataExtraction: { enabled: true  }
        
       }

// REPRESENTATIVE: This CDS View will be joined with other CDS Views based on  MATERIAL Column 
@ObjectModel.representativeKey: 'Cust_no'



define view ZSK_CDSE5_cube_sales as

select from ZSK_CDSE4_fact_sales as H
association [0..1] to ZSK_CDSE1_DIM_MAT as _Material
            on H.matnr = _Material.Material_NO
association [0..1] to ZSK_CDSE1_DIM_VEN as _Vendor
            on H.lifnr = _Vendor.Vendorno
association [0..1] to ZSK_CDSE1_DIM_cust as _Customer
			on H.kunnr = _Customer.Cust_no
                       
{
    key vbeln,
    key posnr,
    ernam,
    erdat,
    // object model annotation will give F4 help in the fiori app
    @ObjectModel.foreignKey.association: '_Material'
    matnr,
    @ObjectModel.foreignKey.association: '_Vendor'
    lifnr,
    @ObjectModel.foreignKey.association: '_Customer'
    kunnr,
//////    matnr,
//////    lifnr,
//////    kunnr,
    @Semantics.quantity.unitOfMeasure: 'UOM'
    @DefaultAggregation: #SUM   // behave like a Group by class
    smeng,
    
    @Semantics.unitOfMeasure: true
    meins as UOM,
    @Semantics.amount.currencyCode: 'waerk'
    @DefaultAggregation: #SUM   // behave like a Group by class
    netpr,
    
    @Semantics.currencyCode: true
    waerk,
    
    
    @Semantics.amount.currencyCode: 'FINal_curr'
    @DefaultAggregation: #SUM   // behave like a Group by class
    FIN_AMT,
    
    @Semantics.currencyCode: true
    FIN_CURR as final_curr,


//expose associations
_Material,
_Vendor,
_Customer

}
