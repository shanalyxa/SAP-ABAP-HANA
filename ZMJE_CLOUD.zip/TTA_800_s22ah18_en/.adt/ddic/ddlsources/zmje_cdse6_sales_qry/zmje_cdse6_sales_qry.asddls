@AbapCatalog.sqlViewName: 'ZMJE_SQLE6_SQ'
@EndUserText.label: 'CDS Sales Query'
// CONSUMPTION : We are exposing this CDS Views to UI5  
@VDM.viewType: #CONSUMPTION

// this is Analytical Query CDS View
@Analytics.query : true

// Expose this CDS Query to the OData Layer
@OData.publish: true

define view ZMJE_CDSE6_SALES_QRY as 

select from ZMJE_CDSE5_CUBE_SALES
{
    
    @Consumption.filter: { selectionType: #RANGE, multipleSelections: true, mandatory: false } // SELECT-OPTION 
    @AnalyticsDetails.query.axis: #ROWS
    key vbeln,
    
    @AnalyticsDetails.query.axis: #ROWS
    key posnr,
    
    @Consumption.filter: { selectionType: #RANGE, multipleSelections: false, mandatory: false } // SELECT-OPTION 
    @AnalyticsDetails.query.axis: #ROWS
    ernam,
    
    @AnalyticsDetails.query.axis: #ROWS
    erdat,
    
    @Consumption.filter: { selectionType: #RANGE, multipleSelections: true, mandatory: false } // SELECT-OPTION 
    @AnalyticsDetails.query.axis: #ROWS
    matnr,
    
    @Consumption.filter: { selectionType: #SINGLE, multipleSelections: true, mandatory: false } // Parameters
    @AnalyticsDetails.query.axis: #ROWS
    lifnr,
    
    @Consumption.filter: { selectionType: #SINGLE, multipleSelections: true, mandatory: false } // Parameters
    @AnalyticsDetails.query.axis: #ROWS
    kunnr,
    
    
    
    @AnalyticsDetails.query.axis: #COLUMNS
    smeng,
    SalesUOM,
    
    @AnalyticsDetails.query.axis: #COLUMNS
    netpr,
   SalesCurr,
    
    @AnalyticsDetails.query.axis: #COLUMNS
    Final_Amt,
    FCurr,
    
    @EndUserText.label: 'Gross Amount'
    @Semantics.amount.currencyCode: 'SalesCurr'
    @DefaultAggregation: #FORMULA 
    @AnalyticsDetails.query.axis: #COLUMNS
    netpr * 10 as Gross_amt
 
}
