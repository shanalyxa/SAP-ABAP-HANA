@AbapCatalog.sqlViewName: 'ZSK_SQLE1_DMAT'
@EndUserText.label: 'Dimension material master view'
// VDM : Virtual Data Model
// BASIC : only for the internal use and it will access tables directly. 
// Means it not used in reporting its used for the internal purpose onlyfor another CDS view
@VDM.viewType: #BASIC

// DIMENSION: it will tellS that CDS view of MASTER DATA
@Analytics.dataCategory: #DIMENSION

// REPRESENTATIVE: This CDS View will be joined with other CDS Views based on  MATERIAL Column 
@ObjectModel.representativeKey: 'Material_NO'


define view ZSK_CDSE1_DIM_MAT as 
select from zma_makt
{
    key matnr as Material_NO,
    maktx as Maktx  
} where spras = 'E'
