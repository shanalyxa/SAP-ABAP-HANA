@AbapCatalog.sqlViewName: 'ZSK_SQLE2_DVEN'
@EndUserText.label: 'CDS Dimension vendor master view'
@Metadata.ignorePropagatedAnnotations: true
// VDM : Virtual Data Model
// BASIC : only for the internal use and it will access tables directly
@VDM.viewType: #BASIC

// DIMENSION: it will tellS that CDS view of MASTER DATA 
@Analytics.dataCategory: #DIMENSION

// REPRESENTATIVE: This CDS View will be joined with other CDS Views based on  MATERIAL Column 
@ObjectModel.representativeKey: 'VendorNo'

define view ZSK_CDSE1_DIM_VEN as 
select from lfa1
{
    key lifnr as Vendorno,
        name1 as VendorName,
        ort01 as VendRegion
}
