@AbapCatalog.sqlViewName: 'ZMJE_SQLE1_DMAT'
@EndUserText.label: 'Dimension Material Master'
// VDM : Virtual Data Model
// BASIC : only for the internal use and it will access tables directly
@VDM.viewType: #BASIC

// DIMENSION: it will tellS that CDS view of MASTER DATA 
@Analytics.dataCategory: #DIMENSION

// REPRESENTATIVE: This CDS View will be joined with other CDS Views based on  MATERIAL Column 
@ObjectModel.representativeKey: 'MaterialNo'

define view ZMJE_CDSE1_DIM_MAT as 
select from zma_makt
{
    key matnr as MaterialNo,
   
    maktx as Maktx
} where spras = 'E'
