@AbapCatalog.sqlViewName: 'ZMJE_SQL1_SV_EB'
@AbapCatalog.preserveKey: true   //false

// @AbapCatalog.preserveKey: false  
// if true  : Inside the SE11 SQL VIEW, keys are selected based on the CDS View 
// if false : Inside the SE11 SQL VIEW, keys are considered from Database tables used in the CDS View 
// 1) preserveKey: true --> doesn't restrict any data  
// 2) Keys in the CDS View doesn't restrict the data
// 3) CDS View "KEY" will help 3rd Party systems(FIORI/BW) to know what are the keys inside my CDS View
// 4) Lines starting in the CDS View with @ symbol we call them as  annotations
// 5) Mandatory annotation in CDS View: @AbapCatalog.sqlViewName
// 6) SQL VIEW name and CDS View Name cannot be same
// 7) After Activation of CDS View we cannot change the CDS View Name or SQL View Name
// 8) Max length of CDS SQL View name is 16 characters
// 9) Max length of CDS DLL and CDS View name is 30 charecters, and not recommanded to give more than 26 charectors
//  because when we expose CDS view to the ODATA then system will add 4 charectords i.e., _CDS


@EndUserText.label: 'Simple View :- CDS Old Template'
define view ZMJE_CDS1_SV_EB as 

select from zma_vbak
{
  key vbeln,
      ernam,
      erdat,
      netwr,
      waerk,
       ( netwr * 10 ) as FIN_AMT
}
