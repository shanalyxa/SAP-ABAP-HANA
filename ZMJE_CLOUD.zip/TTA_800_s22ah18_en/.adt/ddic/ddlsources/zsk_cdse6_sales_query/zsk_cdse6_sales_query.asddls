@AbapCatalog.sqlViewName: 'ZSK_SQLE6_SQ'
@EndUserText.label: 'CDS sales query'
// consumption  : we are exposing this CDS views to UI5
@VDM.viewType: #CONSUMPTION


// this is analyatical Query CDS view

@Analytics.query: true

// Expose thi sCDS query to the ODATA Layer
// system will create odata service for this CDS view . everything will be unstand to fiori by below annotation
@OData.publish: true
 
 
define view ZSK_CDSE6_sales_query as 
 

select from ZSK_CDSE5_cube_sales
{
//    for ODta selection screen we can use below annotation to define the selection screen for the CDS view
    @Consumption.filter: { selectionType :#RANGE, multipleSelections: true , mandatory: false }
    @AnalyticsDetails.query.axis: #ROWS
    key vbeln,
    @AnalyticsDetails.query.axis: #ROWS
    key posnr,
    
    @Consumption.filter: { selectionType :#RANGE, multipleSelections: false , mandatory: false }
    @AnalyticsDetails.query.axis: #ROWS
    ernam,
    
    @AnalyticsDetails.query.axis: #ROWS
    erdat,
    
    @Consumption.filter: { selectionType :#RANGE, multipleSelections: true , mandatory: false }
    @AnalyticsDetails.query.axis: #ROWS
    matnr,
    @Consumption.filter: { selectionType :#SINGLE, multipleSelections: true , mandatory: false }
    @AnalyticsDetails.query.axis: #ROWS
    lifnr,
//    parameters option for odata selection screen
    @Consumption.filter: { selectionType :#SINGLE, multipleSelections: true , mandatory: false }
    @AnalyticsDetails.query.axis: #ROWS
    kunnr,
    @AnalyticsDetails.query.axis: #COLUMNS
    smeng,
    UOM,
    @AnalyticsDetails.query.axis: #COLUMNS
    netpr,
    waerk,
    
    @AnalyticsDetails.query.axis: #COLUMNS
    FIN_AMT,
    @AnalyticsDetails.query.axis: #COLUMNS
    final_curr,
    
    
    @EndUserText.label: 'Gross Amount'
    @Semantics.amount.currencyCode: 'waerk'
////    @DefaultAggregation: #SUM
    @DefaultAggregation: #FORMULA
    @AnalyticsDetails.query.axis: #COLUMNS
    netpr * 10 as Gross_Amt
    
    
// /* Associations */
//    _Customer,
//    _Material,
//    _Vendor

}
