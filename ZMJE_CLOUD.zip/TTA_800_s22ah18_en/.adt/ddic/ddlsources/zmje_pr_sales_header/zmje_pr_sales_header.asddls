@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Projection Sales Header'
@Metadata.allowExtensions: true
@Search.searchable: true
define root view entity ZMJE_PR_SALES_HEADER as projection on ZMJE_IR_SALES_HEADER
{
    key VbelnUuid,
    
    @Search.defaultSearchElement: true
    Vbeln,
    
    @Search.defaultSearchElement: true
    Ernam,
    Erdat,
    Auart,
    Vbtyp,
    
    @Semantics.amount.currencyCode : 'Waerk'
    Netwr,
    @Semantics.currencyCode: true
    Waerk,
    
    @ObjectModel.text.element: ['vkorg_text']
    Vkorg,
    @Semantics.text: true
    _vkorg.vkorg_text as vkorg_text,
    
    @ObjectModel.text.element: ['vtweg_text']
    Vtweg,
    @Semantics.text: true
    _vtweg.vtweg_text as vtweg_text,
    
    @ObjectModel.text.element: ['spart_text']
    Spart,
    @Semantics.text: true
    _spart.spart_text as spart_text,
    
    
    /* Associations */
    _SalesItem : redirected to composition child  ZMJE_PR_SALES_ITEM,
    
    _spart,
    _vkorg,
    _vtweg
}
