@AbapCatalog.sqlViewName: 'ZSK_SQL4_FACT'
@EndUserText.label: 'CDS fact view'

// VDM : Virtual Data Model
//COMPOSITE: CDS VIEW with the combination 2 or more tables or CDS Views
@VDM.viewType: #COMPOSITE

// FACT : This CDS View going to have the Transactional Data 
@Analytics.dataCategory: #FACT

define view ZSK_CDSE4_fact_sales as 
select from zma_vbak as H inner join zma_vbap as I on H.vbeln = I.vbeln
{
  key  H.vbeln,
    key I.posnr,
    H.ernam,
    H.erdat,
    I.matnr,
    I.lifnr,
    I.kunnr,
    
    I.smeng,
    I.meins,
    
    I.netpr,
    I.waerk,

    I.netpr * I.smeng as FIN_AMT,  -- In FACT CDS view we write COMMON Logic for all plants
    I.waerk as FIN_CURR
    
}
