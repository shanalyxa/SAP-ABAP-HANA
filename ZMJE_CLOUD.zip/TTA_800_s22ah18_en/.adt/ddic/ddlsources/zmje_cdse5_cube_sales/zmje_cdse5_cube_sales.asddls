@AbapCatalog.sqlViewName: 'ZMJE_SQLE5_CUBE'
@EndUserText.label: 'CDS CUBE Sales Model'

// VDM : Virtual Data Model
// CONSUMPTION : Means it will be consumed in the BW Bex Query 
@VDM.viewType: #CONSUMPTION

// CUBE : This CDS View will give STAR SCHEMA Mapping
@Analytics: {
              dataCategory: #CUBE,
              // Data Extraction: it will allow BW or UI5 to acces this CDS View
              dataExtraction:{ enabled: true }           
            }
define view ZMJE_CDSE5_CUBE_SALES as 

select from ZMJE_CDSE4_FACT_SALES as H
            association [0..1] to ZMJE_CDSE1_DIM_MAT as _Material
            on H.matnr = _Material.MaterialNo
            
            association [0..1] to ZMJE_CDSE2_DIM_VEN as _Vendor
            on H.lifnr = _Vendor.VendorNo
            
            association [0..1] to ZMJE_CDSE3_DIM_CUST as _Customer
            on H.kunnr = _Customer.CustomerNo
{
    key vbeln,
    key posnr,
    ernam,
    erdat,
    // ObjectModel annaotion will give F4 Help in the FIORI
    @ObjectModel.foreignKey.association: '_Material'
    matnr,
    @ObjectModel.foreignKey.association: '_Vendor'
    lifnr,
    @ObjectModel.foreignKey.association: '_Customer'
    kunnr,
    
    @Semantics.quantity.unitOfMeasure: 'SalesUOM'
    @DefaultAggregation: #SUM
    smeng,
    @Semantics.unitOfMeasure: true
    meins as SalesUOM,
    
    @Semantics.amount.currencyCode: 'SalesCurr'
    @DefaultAggregation: #SUM
    netpr,
    @Semantics.currencyCode: true
    waerk as SalesCurr,
    
    @Semantics.amount.currencyCode: 'FCurr'
    @DefaultAggregation: #SUM
    FIN_AMT as Final_Amt,
    @Semantics.currencyCode: true
    FIN_CURR as FCurr,
    
    //Expose Associations
    _Material,
    _Vendor,
    _Customer
}
